﻿namespace Project.Models
{
    public class Users
    {
        public string? userId {  get; set; }
        public string? pwd {  get; set; }
        public string? userName { get; set; }
        public string? userPhone { get; set; }
        public string? userEmail {  get; set; }
        public string? userAddr {  get; set; }
        public string? gender { get; set; }
    }

}
