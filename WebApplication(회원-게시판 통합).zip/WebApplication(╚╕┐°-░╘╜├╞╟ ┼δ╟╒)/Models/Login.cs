﻿namespace Project.Models
{
    public class Login
    {
        public string? userId { get; set; }
        public string? pwd { get; set; }
    }
}
